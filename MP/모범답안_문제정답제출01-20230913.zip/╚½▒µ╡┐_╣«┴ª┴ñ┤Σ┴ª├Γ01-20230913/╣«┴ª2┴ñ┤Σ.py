#2. letters가 문자열 변수에 저장하고 첫번째와 세번째 문자를 출력하세요.

letter = "python"
print(letter[0])
print(letter[2])



