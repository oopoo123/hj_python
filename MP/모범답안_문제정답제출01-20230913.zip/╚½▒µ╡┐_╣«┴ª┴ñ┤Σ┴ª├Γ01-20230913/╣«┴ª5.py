# 5. 아래 문자열에서 소문자 'a'를 대문자 'A'로 변경하세요.
#
#   string = 'abcdfe2a354a32a'
#   실행 예:
#   Abcdfe2A354A32A

string = 'abcdfe2a354a32a'

string = string.replace('a','A')

print(string)