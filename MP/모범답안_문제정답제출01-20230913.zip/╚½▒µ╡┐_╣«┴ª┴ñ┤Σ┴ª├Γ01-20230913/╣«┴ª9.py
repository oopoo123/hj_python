# 9. 문자열의 좌우의 공백이 있을 때 이를 제거해보세요.
#
#    data = "   삼성전자    "

data = "   삼성전자    "
data = data.strip()
print(data)