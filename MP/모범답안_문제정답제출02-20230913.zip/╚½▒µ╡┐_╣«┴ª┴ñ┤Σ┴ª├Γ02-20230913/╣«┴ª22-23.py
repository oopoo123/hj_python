# 22. 다음의 딕셔너리로부터 key 값으로만 구성된 리스트를 생성하라.
#
#   icecream = {'탱크보이': 1200, '폴라포': 1200, '빵빠레': 1800, '월드콘': 1500, '메로나': 1000}
#
# 23. 다음의 딕셔너리에서 values 값으로만 구성된 리스트를 생성하라.
#
#   icecream = {'탱크보이': 1200, '폴라포': 1200, '빵빠레': 1800, '월드콘': 1500, '메로나': 1000}

icecream = {'탱크보이': 1200, '폴라포': 1200, '빵빠레': 1800, '월드콘': 1500, '메로나': 1000}

icecream_keys = list(icecream.keys())

icecream_values = list(icecream.values())

print(icecream_keys)
print(icecream_values)