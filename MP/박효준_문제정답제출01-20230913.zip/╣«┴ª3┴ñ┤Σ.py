#자동차 번호가 다음과 같을 때 뒤에 4자리만 출력하세요. (슬라이싱)

license_plate = "24가 2210"

print(license_plate[4:8])
print(license_plate[4:])
print(license_plate[-4:])