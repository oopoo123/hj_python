# 변수에 다음과 같은 문자열이 바인딩되어 있습니다.
# 변수에 문자열 더하기와 문자열 곱하기를 사용해서 아래와 같이 출력해보세요.

# 실행 예:python java python java python java python java

t1 = 'python'
t2 = 'java'


print((t1+" "+t2+" ") * 4)

