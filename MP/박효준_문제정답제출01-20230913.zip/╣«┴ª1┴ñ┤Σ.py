#에어컨이 월 48,584원에 무이자 36개월의 조건으로 홈쇼핑에서
#판매되고 있습니다. 총 금액은 계산한 후 이를 화면에 출력하시오. (변수)

aircon = 48584

month = 36

airconPrice = aircon * month

print(airconPrice)
print(f"{airconPrice:,}원")
#  :,를 하면 천단위로 ,를 넣을수 있다
