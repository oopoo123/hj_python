#변수에 다음과 같이 문자열과 정수가 바인딩되어 있을 때 f-string을 사용해서 다음과 같이 출력해보세요.

# 이름: 김민수 나이: 10
# 이름: 이철희 나이: 13

name1 = "김민수"
age1 = 10
name2 = "이철희"
age2 = 13

print(f'이름: {name1} 나이: {age1} \n이름: {name2} 나이: {age2}')

print(f'이름: {name1} 나이: {age1}')
print(f'이름: {name2} 나이: {age2}')