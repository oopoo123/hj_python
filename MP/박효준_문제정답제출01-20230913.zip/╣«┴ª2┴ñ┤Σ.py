#letters가 문자열 변수에 저장하고 첫번째와 세번째 문자를 출력하세요.(인덱싱)
a = "letters"
print(a[0],a[2])

letters = "python"
print(letters[0],letters[2])