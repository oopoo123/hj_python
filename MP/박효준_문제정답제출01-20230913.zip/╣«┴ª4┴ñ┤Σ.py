#url 에 저장된 웹 페이지 주소에서 도메인을 출력하세요. (슬라이싱)

 #실행 예: kr
url = "http://sharebook.kr"

print(url[17:])
print(url[-2:])

